#Alles importeren wat nodig is.
from machine import Pin
import time
import machine
import neopixel
import RGB1602
from math import pi, sin


# De gebruikte led pins defineren.
led = Pin(25, Pin.OUT)
np = neopixel.NeoPixel(machine.Pin(15), 8)
lcd = RGB1602.RGB1602(16, 2)

def neopixel_clear():
    # functie om alle leds uit te maken.
        for i in range(8):
            np[i] = [0,0,0]
            np.write()

def waiting():

    lcd = RGB1602.RGB1602(16, 2)
    # Op het LCD scherm laten zien 'wating for the users status...'
    lcd.clear()
    lcd.printout('Waiting for the')
    lcd.at(1, 2)
    lcd.printout('users status...')

    # Regenboog wave op de led strip en het LCD scherm.
    deg2rad = pi / 180
    t = 0
    while t < 360:
        r = int((abs(sin(deg2rad * t))) * 255)
        g = int((abs(sin(deg2rad * (t + 60)))) * 255)
        b = int((abs(sin(deg2rad * (t + 120)))) * 255)
        for l in range(8):
            np[l] = [r, g, b]
            np.write()
        lcd.set_rgb(r, g, b)
        t = t + 3
        time.sleep(0.1)

def offline():
    lcd = RGB1602.RGB1602(16, 2)
    lcd.clear()
    # Als de user offline is wordt het LCD scherm Rood
    # En print een zin uit.
    lcd.set_rgb(255, 0, 0)
    # De eerste regel
    for char in "De gebruiker is:":
        lcd.printout(char)
        time.sleep(0.1)
    # De tweede regel
    lcd.at(1, 2)
    for char in "Offline :(":
        lcd.printout(char)
        time.sleep(0.1)

def online():
    lcd = RGB1602.RGB1602(16, 2)
    # Als de user online is wordt het LCD scherm Groen.
    # En print een zin uit.
    lcd.clear()
    lcd.set_rgb(0, 255, 0)

    # De eerste regel.
    for char in "De gebruiker is:":
        lcd.printout(char)
        time.sleep(0.1)
    # De tweede regel.
    lcd.at(1, 2)
    for char in "Online :)":
        lcd.printout(char)
        time.sleep(0.1)

def neo(color):
    neopixel_clear()
    led(0)
    for i in range(8):
        np[i]= color
    np.write()

def controller():
    # De onboard led laten knipperen als er succesvol geflashed wordt.
    waiting()
    for _ in range(5):
        led(0)
        time.sleep(.1)
        led(1)
        time.sleep(.1)

    while True:

        data = input()
        while data not in ['0','1']:
            data = input()

        # Als de gebruiker offline is.
        if data == '0':
           neo([255,0,0])
           led.value(0)
           offline()

        # Als de gebruiker online is.
        elif data == '1':
            neo([0,255,0])
            led.value(1)
            online()

controller()