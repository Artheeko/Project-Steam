## Doelstelling

Voor dit project gaan we voor Steam een grafische weergave maken die inzicht geeft in het gaming gedrag van personen op
Steam.
Het product bestaat uit een dashboard die communiceert met de dataset van Steam. Met behulp van statistiekfuncties
willen we de gebruiker inzicht geven in de data uit Steam. Ook communiceert het dashboard met de Raspberry Pi Pico met
de inzet van één hardwarecomponent. Tenslotte willen we de customer journey analyseren. Indien er tijd over is zullen
we nog aanvullende en/of onderdelen aan het product toevoegen.

## Project leden
- Matthew Bijlhout, 1833635, @matthewjb_02
- Jamiro Kolf, 1815432, @Artheeko
- Tamzid Mafuzur Rahman, 1835971, @TamzidMafuzurHU
- Afzal Mohan, 1829814, @AfzalMohanHU
- ELias Lemkaddem el Founti, 1836241, @eliasfounti
- Mariam Bakkali Kasmi, 1844148, @mariambk


## Instructies

Om het dashboard te zien drukt de gebruiker op run rechtboven de IDE. Tevens kan de gebruiker 
ook Shift-Alt-F10 indrukken.
