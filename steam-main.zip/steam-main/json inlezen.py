import json
jsonbestand = open("steam.json", "r")
data = json.load(jsonbestand)
for i in data:
    print(i)
